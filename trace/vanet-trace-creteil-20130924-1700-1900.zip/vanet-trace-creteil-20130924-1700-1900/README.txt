Microscopic vehicular mobility trace of Europarc roundabout, Creteil, France 
by Marie-Ange Lèbre, Frédéric Le Mouël is licensed under a Creative Commons 
Attribution-NonCommercial 4.0 International License.

This archive includes the following files
.
├── LICENCE-CC-BY-NC-4.0.txt
├── README.txt
└── vanet-trace-creteil-20130924-1700-1900.csv

